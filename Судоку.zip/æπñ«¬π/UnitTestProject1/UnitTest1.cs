﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Sudoku;

namespace Sudoku.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMapShuffling()
        {
            var sudokuForm = new Form1();
            sudokuForm.GenerateMap();
            var originalMap = (int[,])sudokuForm.map.Clone();
            sudokuForm.ShuffleMap(0);
            CollectionAssert.AreNotEqual(originalMap, sudokuForm.map);
        }

        [TestMethod]
        public void TestGameCompletion()
        {
            var sudokuForm = new Form1();
            sudokuForm.GenerateMap();

            for (int i = 0; i < Form1.n * Form1.n; i++)
                for (int j = 0; j < Form1.n * Form1.n; j++)
                    sudokuForm.buttons[i, j].Text = sudokuForm.map[i, j].ToString();

            sudokuForm.button1_Click(null, null);
            Assert.IsTrue(true); 
        }
    }
}






